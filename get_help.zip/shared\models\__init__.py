"""Shared data models and schemas."""
