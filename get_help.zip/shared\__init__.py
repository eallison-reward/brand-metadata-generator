"""Brand Metadata Generator - Shared Modules."""
