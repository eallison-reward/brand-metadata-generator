"""Shared utilities for conversational interface agent."""
